
import React, { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

interface ExtractionData {
  answer: {
    [section: string]: string | object;
  };
  time_taken: string;
  status: string;
  sections_extracted?: string[];
}

interface ExtractInfoProps {
  selectedFile: File | null;
}

const formatSectionName = (section: string) =>
  section.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());

export const ExtractInfo: React.FC<ExtractInfoProps> = ({ selectedFile }) => {
  const [extractionData, setExtractionData] = useState<ExtractionData | null>(
    null
  );
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchExtraction = async () => {
      setLoading(true);
      setError(null);
      try {
        console.log("📡 Fetching extraction data from backend...");
        const response = await fetch("http://127.0.0.1:5000/extract", {
          method: "GET",
        });

        if (!response.ok) {
          throw new Error("❌ Failed to fetch extraction data from server");
        }

        const data: ExtractionData = await response.json();
        setExtractionData(data);
        console.log("✅ Extraction data received:", data);
      } catch (err: any) {
        console.error("❌ Error fetching extraction data:", err);
        setError(
          err.message || "An error occurred while fetching extraction data"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchExtraction();
  }, []);

  return (
    <div className="w-full min-h-screen bg-gray-100 flex items-center justify-center px-4 py-10">
      <div className="animate-fade-in animate-slide-up w-full max-w-5xl bg-white p-10 rounded-2xl shadow-xl">
        <h2 className="text-4xl font-bold text-center text-[#8b4513] mb-8">
          Extracted Contract Information
        </h2>

        {loading ? (
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="animate-spin w-10 h-10 text-blue-600" />
            <p className="text-gray-700 text-lg">Extracting information...</p>
          </div>
        ) : error ? (
          <p className="text-red-600 text-lg text-center font-medium">
            {error}
          </p>
        ) : extractionData && typeof extractionData.answer === "object" ? (
          <>
            <div className="max-h-[600px] overflow-y-auto text-gray-800 text-lg leading-relaxed p-4 bg-gray-50 border border-gray-300 rounded-lg space-y-6">
              {[
                {
                  label: "1) Entities Name & Address Details",
                  key: "entities",
                },
                { label: "2) Contract Start Date & End Date", key: "dates" },
                { label: "3) Scope", key: "scope" },
                { label: "4) SLA Clause", key: "sla" },
                { label: "5) Penalty Clause", key: "penalty" },
                { label: "6) Confidentiality Clause", key: "confidentiality" },
                {
                  label: "7) Renewal and Termination Clause",
                  key: "termination",
                },
                { label: "8) Commercials / Payment Terms", key: "commercials" },
                { label: "9) Risks / Assumptions", key: "risks" },
              ].map(({ label, key }) => {
                const content = extractionData.answer[key];
                return (
                  <div key={key}>
                    <h3 className="text-xl font-semibold text-indigo-700 mb-2 border-b pb-1">
                      {label}
                    </h3>
                    <ReactMarkdown>
                      {typeof content === "string"
                        ? content
                        : JSON.stringify(content, null, 2)}
                    </ReactMarkdown>
                  </div>
                );
              })}
            </div>

            <p className="mt-6 text-sm text-gray-500 text-center">
              ⏱️ Total Processing Time: {extractionData.time_taken}
            </p>
          </>
        ) : (
          <p className="text-gray-600 text-lg text-center">
            No extraction data available yet.
          </p>
        )}
      </div>
    </div>
  );
};

export default ExtractInfo;
